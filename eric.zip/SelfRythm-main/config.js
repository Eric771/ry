module.exports = {
    token: "MTIwNDQxMzc5ODA0NDQwMTczNQ.GY0Uc3.2YmRaiDmpRDl7onDBwKgic3LD_0fvuJT3iMlNU",
    prefix: "!"
};

/* remove .example from the name of this file */